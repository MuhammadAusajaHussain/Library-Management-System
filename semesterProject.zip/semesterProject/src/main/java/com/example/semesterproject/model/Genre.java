package com.example.semesterproject.model;

public class Genre {

    private String genre_Name;

    private String genre_Description;

    public String getGenre_Name() {
        return genre_Name;
    }

    public void setGenre_Name(String genre_Name) {
        this.genre_Name = genre_Name;
    }

    public String getGenre_Description() {
        return genre_Description;
    }

    public void setGenre_Description(String genre_Description) {
        this.genre_Description = genre_Description;
    }
}

