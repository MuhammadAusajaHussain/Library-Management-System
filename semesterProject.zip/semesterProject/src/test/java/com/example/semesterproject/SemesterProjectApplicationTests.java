package com.example.semesterproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SemesterProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
